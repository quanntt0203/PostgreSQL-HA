# PostgreSQL Command Util

## PSQL
```postgresql
psql -U user -h host -p port -d database
>
database=#
\l -- list out of databases
\dt -- list tables
\d+ table_name -- descride table Structure
\i /path/to/your_file.sql
```

## Load SQL file
```bash
psql -U postgres -d your_database_name -f /path/to/your_file.sql
```
## pg_ctl Command

```bash
# Start PostgreSQL service
# Start with the LC_ALL fix we discussed earlier
LC_ALL=en_US.UTF-8 pg_ctl -D /path/to/replica/data restart

# Start existing PGDATA
pg_ctl start -D /path/to/data/directory

# Stop PostgreSQL service
pg_ctl stop -D /path/to/data/directory

# Stop with different modes
pg_ctl stop -D /path/to/data/directory -m fast
pg_ctl stop -D /path/to/data/directory -m immediate
pg_ctl stop -D /path/to/data/directory -m smart

# Restart PostgreSQL service
pg_ctl restart -D /path/to/data/directory

# Reload configuration
pg_ctl reload -D /path/to/data/directory

# Check status
pg_ctl status -D /path/to/data/directory

# Initialize database cluster
pg_ctl initdb -D /path/to/data/directory

# Promote standby server
pg_ctl promote -D /path/to/data/directory

# Kill PostgreSQL process
pg_ctl kill TERM process_id
pg_ctl kill INT process_id
pg_ctl kill QUIT process_id
```

## Patroni Command
```bash
# Show cluster status
patronictl list

# Show detailed cluster status with topology
patronictl list -f pretty

# Show cluster status in JSON format
patronictl list -f json

# Show cluster topology
patronictl topology

# Show cluster history
patronictl history

# Switchover (planned failover)
patronictl switchover cluster_name

# Switchover to specific node
patronictl switchover cluster_name --master master_node --candidate target_node

# Failover (emergency)
patronictl failover cluster_name

# Failover to specific candidate
patronictl failover cluster_name --candidate target_node

# Restart cluster
patronictl restart cluster_name

# Restart specific node
patronictl restart cluster_name node_name

# Restart with pending restart
patronictl restart cluster_name node_name --pending

# Reload configuration
patronictl reload cluster_name

# Reload specific node
patronictl reload cluster_name node_name

# Reinitialize node
patronictl reinit cluster_name node_name

# Remove node from cluster
patronictl remove cluster_name node_name

# Pause cluster (disable automatic failover)
patronictl pause cluster_name

# Resume cluster (enable automatic failover)
patronictl resume cluster_name

# Edit cluster configuration
patronictl edit-config cluster_name

# Show cluster configuration
patronictl show-config cluster_name

# Flush scheduled events
patronictl flush cluster_name

# Query cluster members
patronictl query cluster_name --member node_name --command "SELECT version()"

# Enable maintenance mode
patronictl pause cluster_name --wait

# Check cluster version
patronictl version
```

## ETCD Commands - 

```bash
# Basic cluster operations
etcdctl member list
etcdctl member add node_name --peer-urls=http://node_ip:2380
etcdctl member remove member_id
etcdctl member update member_id --peer-urls=http://new_ip:2380

# Key-value operations
etcdctl put key value
etcdctl get key
etcdctl get key --print-value-only
etcdctl get --prefix /path/ --keys--only
etcdctl del key
etcdctl del --prefix /path/

# Watch operations
etcdctl watch key
etcdctl watch --prefix /path/
etcdctl watch key --rev=revision_number

# Cluster health and status
etcdctl endpoint health
etcdctl endpoint status
etcdctl endpoint hashkv
etcdctl alarm list
etcdctl alarm disarm

# Backup and restore
etcdctl snapshot save backup.db
etcdctl snapshot restore backup.db --data-dir /new/data/dir
etcdctl snapshot status backup.db

# Authentication and authorization
etcdctl user add username
etcdctl user delete username
etcdctl user list
etcdctl user passwd username
etcdctl role add rolename
etcdctl role delete rolename
etcdctl role list
etcdctl role grant-permission rolename readwrite key
etcdctl user grant-role username rolename
etcdctl auth enable
etcdctl auth disable

# Lease operations
etcdctl lease grant 60
etcdctl lease revoke lease_id
etcdctl lease timetolive lease_id
etcdctl lease keep-alive lease_id

# Compaction and defragmentation
etcdctl compact revision_number
etcdctl defrag
etcdctl defrag --data-dir /path/to/data

# Maintenance
etcdctl move-leader target_member_id
etcdctl check perf
etcdctl check datascale
```

## CITUS Command

```sql
-- Cluster Management
SELECT citus_version();
SELECT * FROM master_get_active_worker_nodes();
SELECT * FROM citus_get_active_worker_nodes();

-- Add/Remove Worker Nodes
SELECT master_add_node('worker-host', 5432);
SELECT citus_add_node('worker-host', 5432);
SELECT master_remove_node('worker-host', 5432);
SELECT citus_remove_node('worker-host', 5432);

-- Activate/Deactivate Worker Nodes
SELECT master_activate_node('worker-host', 5432);
SELECT master_disable_node('worker-host', 5432);

-- Table Distribution
SELECT create_distributed_table('table_name', 'distribution_column');
SELECT create_distributed_table('table_name', 'distribution_column', 'hash');
SELECT create_distributed_table('table_name', 'distribution_column', 'append');
SELECT create_distributed_table('table_name', 'distribution_column', 'range');

-- Reference Tables
SELECT create_reference_table('table_name');

-- Shard Management
SELECT master_create_empty_shard('table_name');
SELECT master_modify_multiple_shards('UPDATE table_name SET column = value WHERE condition');

-- Rebalancing
SELECT citus_rebalance_start();
SELECT citus_rebalance_stop();
SELECT citus_rebalance_wait();
SELECT rebalance_table_shards('table_name');

-- Shard Information
SELECT * FROM pg_dist_shard;
SELECT * FROM pg_dist_shard_placement;
SELECT * FROM citus_shards;
-- Note: citus_shard_sizes may not exist in all Citus versions
SELECT * FROM citus_shard_sizes;

-- Alternative ways to check shard sizes if citus_shard_sizes doesn't exist:
-- First, check the structure of citus_tables to see available columns
\d citus_tables;
-- Or using SQL:
SELECT column_name, data_type FROM information_schema.columns 
WHERE table_name = 'citus_tables';

-- Method 1: Check distributed table sizes (corrected syntax)
SELECT 
    table_name,
    pg_size_pretty(pg_total_relation_size(table_name::regclass)) as table_size
FROM citus_tables;

-- Method 1b: Alternative if above doesn't work - use pg_dist_partition
SELECT 
    logicalrelid::regclass AS table_name,
    pg_size_pretty(pg_total_relation_size(logicalrelid)) as table_size
FROM pg_dist_partition;

-- Method 2: Get detailed shard size information
SELECT 
    s.logicalrelid::regclass AS table_name,
    s.shardid,
    s.shardminvalue,
    s.shardmaxvalue,
    pg_size_pretty(pg_relation_size(concat(s.logicalrelid::regclass::text, '_', s.shardid))) AS shard_size
FROM pg_dist_shard s
ORDER BY s.logicalrelid, s.shardid;

-- Method 3: Check if views/tables exist and their structure
SELECT schemaname, tablename FROM pg_tables WHERE tablename LIKE '%citus%';
SELECT schemaname, viewname FROM pg_views WHERE viewname LIKE '%citus%';

-- Method 4: Get all distributed tables and their sizes
SELECT 
    n.nspname AS schema_name,
    c.relname AS table_name,
    pg_size_pretty(pg_total_relation_size(c.oid)) AS table_size
FROM pg_dist_partition p
JOIN pg_class c ON c.oid = p.logicalrelid
JOIN pg_namespace n ON n.oid = c.relnamespace
ORDER BY pg_total_relation_size(c.oid) DESC;

-- Node and Cluster Status
SELECT * FROM citus_check_cluster_node_health();
#SELECT * FROM master_get_table_metadata('test_table');
SELECT get_shard_id_for_distribution_column('test_table', value);

-- Local Table Operations
SELECT citus_add_local_table_to_metadata('table_name');
SELECT undistribute_table('table_name');

-- Columnar Storage (Citus 11+)
SELECT alter_table_set_access_method('table_name', 'columnar');
SELECT alter_table_set_access_method('table_name', 'heap');

-- Background Tasks
SELECT * FROM citus_tasks;
SELECT citus_task_wait(task_id);

-- Statistics and Monitoring
SELECT * FROM citus_stat_activity;
SELECT * FROM citus_lock_waits;
SELECT * FROM citus_dist_stat_activity;

-- Connection Pooling
SELECT start_connection_recovery();
SELECT recover_prepared_transactions();

-- Tenant Isolation (Multi-tenant)
SELECT isolate_tenant_to_new_shard('table_name', tenant_id);

-- Cleanup Operations
SELECT master_copy_shard_placement(shard_id, 'source_host', source_port, 'target_host', target_port);
SELECT master_move_shard_placement(shard_id, 'source_host', source_port, 'target_host', target_port);

-- Configuration
SELECT run_command_on_workers('SHOW shared_preload_libraries;');
SELECT run_command_on_coordinator('SHOW citus.node_conninfo;');

-- Schema-based Sharding (Citus 12+)
SELECT citus_schema_distribute('schema_name');
SELECT citus_schema_undistribute('schema_name');

-- Table Colocation
SELECT mark_tables_colocated('table1', ARRAY['table2', 'table3']);

-- Maintenance
SELECT master_drain_node('worker-host', 5432);
SELECT citus_drain_node('worker-host', 5432);
```

