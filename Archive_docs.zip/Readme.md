# Run this inside your Postgres container or on the host

## Login as root user

```bash
docker exec -u 0 -it postgres_coord3 bash
```
## Generate pgbouncer userlist
```bash
psql -h 127.0.0.1 -U postgres -d postgres -c "SELECT concat('\"', usename, '\" \"', passwd, '\"') FROM pg_shadow;" > /etc/pgbouncer/userlist.txt

# Check server IP
select inet_server_addr();

# host_standby
SELECT pg_is_in_recovery();

# Get hostname

```

## Patroni Configuration
```bash
EXPOSE PATRONI_CONFIG_FILE=/etc/patroni.yml
EXPOSE PATRONI_SCOPE=demo-cluster
EXPOSE PATRONI_ETCD3_HOSTS=etcd:2379
```

## Patroni Commands
```bash
# Access container
docker exec -it node2

# Basic patroni control
patronictl -c /etc/patroni/patroni.yml [options]

# List cluster status
docker exec -it node2 patronictl

# Manual switchover (when leader is healthy)
patronictl switchover

# Failover commands (when leader is down)
patronictl -c /etc/patroni/patroni.yml failover
patronictl -c /etc/patroni/patroni.yml failover --candidate node2 --force
```

## Failover vs Switchover Comparison

| Feature | Failover | Switchover |
|---------|----------|------------|
| Cluster Health | Used when Leader is down or broken | Used when Leader is healthy |
| Data Safety | Risk of small data loss (promotes "as-is") | Safe (waits for sync/checkpoint) |
| Candidate | Must specify a candidate | Optional (can let Patroni pick) |
| Scheduling | Immediate only | Can be scheduled for later |

## Multi-Master Replication (MMR)

### 1. Patroni + Logical Replication (Traditional MMR)

#### 1.1 - Config wal_level
In your patroni.yml, you must ensure the WAL level is set to logical so that data can be decoded for MMR.
```yml
postgresql:
  parameters:
    wal_level: logical
    max_replication_slots: 10
    max_wal_senders: 10
```
#### 1.2 - Use Logical Slots
Patroni can manage logical replication slots so they survive a failover. Without this, if your master fails, your MMR connection will break.
```yml
slots:
  mmr_slot:
    type: logical
    database: my_database
    plugin: pgoutput
```

#### 1.3 - Setup pglogical extention or BDR
You will create a "node" on Cluster A and a "subscription" on Cluster B, then do the same in reverse.

### 2. Patroni + Citus (Distributed MMR)

Patroni now officially supports Citus, which is often a better "Postgres-native" way to scale writes

```bash
docker pull citusdata/citus:postgres_16
```

#### 2.1 - Bootstrap with Citus
Run on both nodes
```sql
-- Check version
SELECT citus_version();

-- For Citus 11.0 and 12.0
SELECT citus_finish_pg_upgrade();

-- check nodes
SELECT * FROM pg_dist_node;

-- check citus group
select * from pg_dist_local_group;
```
#### 2.1 - Coordinator & Workers

Check citus status
```sql
-- 1. Verify Citus is in memory
SHOW shared_preload_libraries; 
-- If 'citus' is not in this list, your Docker container needs a restart.

-- 2. Create the extension
CREATE EXTENSION IF NOT EXISTS citus;

-- 3. Verify the function now exists
SELECT * FROM citus_get_active_worker_nodes();

-- 4. Replace 'worker1_node2' with the actual DNS/IP of your worker container
SELECT * FROM citus_add_node('worker1_node2', 5432);
```
On the Coordinator
```sql
-- 1. Create a standard table
CREATE TABLE test_table (id int primary key, data text);

-- 2. Turn it into a Citus distributed table
SELECT create_distributed_table('test_table', 'id');

-- 3. Insert some data
INSERT INTO test_table VALUES (1, 'hello from coordinator');

```
Reference tables (Sync to all workers).
If you have a table (like a list of countries or categories) that you want to be available on every worker for fast local joins.
```sql
CREATE TABLE categories (id int PRIMARY KEY, name text);
SELECT create_reference_table('categories');
```

List distributed tables
```sql
select * from pg_dist_partition;
--partmethod: Shows how it is distributed ('h' for hash, 'a' for append, or 'n' for none/reference tables)
```

Checking Shard Count
```sql
SELECT logicalrelid AS table_name, 
       count(*) AS shard_count
FROM pg_dist_shard
GROUP BY logicalrelid;

SELECT 
    relname AS shard_name, 
    pg_size_pretty(pg_total_relation_size(relid)) AS size_on_disk
FROM pg_stat_user_tables;
```
Global identity & Alternative: UUIDs
```sql
-- On the Coordinator
CREATE TABLE users (
    user_id bigint GENERATED ALWAYS AS IDENTITY,
    username text
);

-- Distribute the table
SELECT create_distributed_table('users', 'user_id');
```

The "Best Practice" summary:
```note
For Sharding/Distributed Data: Always run CREATE TABLE + create_distributed_table on the Coordinator.

For Data Entry: Once the table is created, you can use the Worker to INSERT, UPDATE, or COPY data directly.
```

#### 2.3 - Add a second Distributed databse

On the Coordinator:

```sql
CREATE DATABASE pgbench_db;
\c pgbench_db
CREATE EXTENSION citus;
INSERT INTO pg_dist_authinfo (nodeid, rolename, authinfo)
VALUES (0, 'postgres', 'password=postgrespass');
-- You must add the workers to the metadata of THIS specific DB
SELECT * from master_add_node('postgres_work1-1', 5432);
SELECT * from master_add_node('postgres_work1-2', 5432);
```

Remove none leader nodes
```sql
SELECT citus_remove_node('postgres_coord1', 5432);
SELECT citus_remove_node('postgres_coord2', 5432);
SELECT citus_remove_node('postgres_work1-2', 5432);
SELECT citus_remove_node('postgres_work2-2', 5432);
```

Verification leader worker nodes
```sql
SELECT nodename, count(*) as shard_count 
FROM pg_dist_shard_placement 
GROUP BY nodename;
```

#### 2.4 Stresstest with pgbench

Initialize a test with a scale factor of 100
```bash
pgbench -i -s 100 -h 127.0.0.1 -p 5452 -U postgres pgench_db
```

Distribute the tables across the workers
```sql
pgbench_db=# 
SELECT create_distributed_table('pgbench_accounts', 'aid');
SELECT create_distributed_table('pgbench_branches', 'bid');
SELECT create_distributed_table('pgbench_tellers', 'tid');
```

Sample Output
```bash
pgbench_db=# SELECT create_distributed_table('pgbench_accounts', 'aid');
NOTICE:  Copying data from local table...
NOTICE:  copying the data has completed
DETAIL:  The local data in the table is no longer visible, but is still on disk.
HINT:  To remove the local data, run: SELECT truncate_local_data_after_distributing_table($$public.pgbench_accounts$$)
create_distributed_table
--------------------------
(1 row)
```

Truncate local Coord Leader after distributing_table
```sql
SELECT truncate_local_data_after_distributing_table($$public.pgbench_accounts$$)
SELECT truncate_local_data_after_distributing_table($$public.pgbench_branches$$);
SELECT truncate_local_data_after_distributing_table($$public.pgbench_tellers$$);
```

Verify distribution on the Coord Leader

```sql
SELECT * FROM citus_shards where table_name::text='pgbench_accounts';
```

Launch the test
```bash
pgbench -c 20 -j 4 -T 300 -h 127.0.0.1 -p 5452 -U postgres pgbench_db
```

### 3. pglogical MMR

#### replicator permission

```sql

CREATE ROLE replication_appdb WITH 
    NOLOGIN 
    REPLICATION 
    PASSWORD 'replpass';

-- Grant access to your application schemas
GRANT USAGE ON SCHEMA public, app TO replication_appdb;

-- Grant read access to all current tables
GRANT SELECT ON ALL TABLES IN SCHEMA public, app TO replication_appdb;

-- Ensure the user can read tables created in the future
ALTER DEFAULT PRIVILEGES IN SCHEMA public, app 
    GRANT SELECT ON TABLES TO replication_appdb;

-- Grant access to the pglogical extension's schema
GRANT USAGE ON SCHEMA pglogical TO replication_appdb;

-- Grant select on all metadata tables (nodes, sets, etc.)
GRANT SELECT ON ALL TABLES IN SCHEMA pglogical TO replication_appdb;

-- Grant execution on the specific function that failed
GRANT EXECUTE ON FUNCTION pg_catalog.pg_replication_origin_session_setup(text) TO replication_appdb;

-- Grant execution on all pglogical functions
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA pglogical TO replication_appdb;

-- Assign to replicator
GRANT replication_appdb TO replicator;

-- Crucial: Grant the internal pglogical provider role
-- GRANT pglogical_node_provider TO replication_appdb; -- NOT EXISTS

-- LAST one(optional)
ALTER USER replicator WITH SUPERUSER;

```

#### 3.1 Node 1
```sql
CREATE EXTENSION pglogical IF NOT EXISTS;
SELECT pglogical.create_node(
    node_name := 'publisher_node1', 
    dsn := 'host=pglogical_node1 port=5432 dbname=appdb user=replicator password=replpass'
);

-- UPDATE pglogical.node_interface 
-- SET if_dsn = 'host=pglogical_node1 port=5432 dbname=appdb user=replicator password=replpass'
-- WHERE if_nodeid = (SELECT node_id FROM pglogical.node WHERE node_name = 'publisher_node1');

SELECT pglogical.create_replication_set(
  set_name := 'repl_data_store', 
  replicate_insert := true,
  replicate_update := true,
  replicate_delete := true,
  replicate_truncate := false
);
```
Add Specific Tables to the Set
```sql
-- Add a single table
SELECT pglogical.replication_set_add_table(
    set_name := 'repl_data_store',
    relation := 'app.store1',
    synchronize_data := false
);

-- Add all tables in a specific schema
SELECT pglogical.replication_set_add_all_tables(
    set_name := 'repl_data_store',
    schema_names := ARRAY['app', 'public'],
    synchronize_data := true
);

-- Check tables in the replication_set
SELECT * FROM pglogical.replication_set_table;
```

#### 3.2 Node 3
```sql
CREATE EXTENSION pglogical;
SELECT pglogical.create_node(
    node_name := 'publisher_node3', 
    dsn := 'host=pglogical_node3 port=5432 dbname=appdb user=replicator password=replpass');
-- Subscribe to Node 1
SELECT pglogical.create_subscription(
    subscription_name := 'sub_to_publisher_node1',
    provider_dsn := 'host=pglogical_node1 port=5432 dbname=appdb user=replicator passfile=/var/lib/postgresql/pgpass',
    replication_sets := '{repl_data_store}',
    synchronize_structure := false,
    synchronize_data := true
);

-- On the destination node (e.g., Node 3)
SELECT pglogical.alter_subscription_add_replication_set(
    subscription_name := 'sub_to_publisher_node1',
    replication_set := 'repl_data_store'
);

-- Remove
SELECT pglogical.alter_subscription_remove_replication_set(
    subscription_name := 'sub_to_publisher_node1',
    replication_set := 'default'
);

-- check subscription status
SELECT * FROM pglogical.show_subscription_status();

```

#### 3.3 Node 1

```sql
-- Subscribe to Node 3
--SELECT pglogical.drop_subscription('sub_to_publisher_node3');
SELECT pglogical.create_subscription(
    subscription_name := 'sub_to_publisher_node3',
    provider_dsn := 'host=pglogical_node3 port=5432 dbname=appdb user=replicator password=replpass',
    replication_sets := '{repl_data_store}',
    synchronize_structure := false, -- Manually ensure schemas match first
    synchronize_data := false
);
```

#### 3.3 Node 1 to Node2
```sql
-- Subscribe to Node 2
SELECT pglogical.create_subscription(
    subscription_name := 'sub_to_node2',
    provider_dsn := 'host=node2 port=5432 dbname=postgres'
);
```
Important: Handling "Infinite Loops"
By default, pglogical uses a "last update wins" strategy based on those timestamps.
```yml
#In your patroni.yml
track_commit_timestamp: on
```

### 4. Kube Patroni

Build Dockerfile

```bash
docker build -t kube-custom-patroni:1.0 .
```

Create namespace
```bash
kubectl create namespace kube-postgres-ha
# then
kubectl apply -k .
```

### 5. Comparison of MMR Solutions for Patroni

|Solution|Complexity|Best For|Patroni Support|
|--------|----------|--------|---------------|
|pglogical|Medium,Bidirectional syncing of specific tables.|Via logical slots.|
|BDR (EDB)|High|Enterprise-grade global active-active.|Proprietary.|
|Citus|Medium|Sharding and high-volume write scaling.|Native Integration.|