#!/bin/bash
# pgBackRest setup script to run after Patroni starts

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}Starting pgBackRest setup...${NC}"

# Configuration
STANZA_NAME="${PGBACKREST_STANZA:-citus_worker1}"
BACKUP_SERVER="${PGBACKUP_SERVER:-pgbackup_server}"
BACKUP_USER="${PGBACKUP_USER:-bgbackrest}"


# Function to setup SSH keys
setup_ssh_keys() {
    echo -e "${YELLOW}Setting up SSH keys for pgBackRest...${NC}"
        
    # Generate SSH key if it doesn't exist
    if [ ! -f "/var/lib/postgresql/.ssh/id_ed25519" ]; then
        echo -e "${YELLOW}Generating SSH key...${NC}"
        ssh-keygen -t ed25519 -N "" -f /var/lib/postgresql/.ssh/id_ed25519
        chmod 600 /var/lib/postgresql/.ssh/id_ed25519
        chmod 644 /var/lib/postgresql/.ssh/id_ed25519.pub
        echo -e "${GREEN}SSH key generated${NC}"
    else
        echo -e "${GREEN}SSH key already exists${NC}"
    fi
    
    # Setup known_hosts
    if [ ! -f "/var/lib/postgresql/.ssh/known_hosts" ]; then
        touch /var/lib/postgresql/.ssh/known_hosts
        chown postgres:postgres /var/lib/postgresql/.ssh/known_hosts
        chmod 600 /var/lib/postgresql/.ssh/known_hosts
    fi
    
    # Add backup server to known_hosts if not already present
    if ! ssh-keygen -F "$BACKUP_SERVER" >/dev/null 2>&1; then
        echo -e "${YELLOW}Adding backup server to known_hosts...${NC}"
        ssh-keyscan -H "$BACKUP_SERVER" >> /var/lib/postgresql/.ssh/known_hosts 2>/dev/null || true
    fi

    sshpass -p '123open' ssh-copy-id pgbackrest@pgbackup_server 2>/dev/null || true

}

# Function to test SSH connectivity
test_ssh_connectivity() {
    echo -e "${YELLOW}Testing SSH connectivity to backup server...${NC}"
    
    local max_attempts=10
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if ssh pgbackrest@pgbackup_server date 2>/dev/null; then
            echo -e "${GREEN}SSH connectivity test successful${NC}"
            return 0
        fi
                
        echo -e "${YELLOW}SSH test attempt $attempt/$max_attempts failed, retrying...${NC}"
        sleep 5
        ((attempt++))
    done
    
    echo -e "${RED}Warning: Could not establish SSH connection to backup server${NC}"
    return 1
}


# Main execution
main() {
    echo -e "${GREEN}=== pgBackRest Setup Script ===${NC}"
    echo -e "${YELLOW}Stanza: $STANZA_NAME${NC}"
    echo -e "${YELLOW}Backup Server: $BACKUP_SERVER${NC}"
    echo -e "${YELLOW}Backup User: $BACKUP_USER${NC}"
    echo ""
    
    setup_ssh_keys
    test_ssh_connectivity
    
    echo -e "${GREEN}=== pgBackRest setup completed ===${NC}"
}

# Run main function
main