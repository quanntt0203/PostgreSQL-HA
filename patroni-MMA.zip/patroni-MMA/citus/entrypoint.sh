#!/bin/bash
set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}Starting pgBackRest setup...${NC}"

# Configuration
STANZA_NAME="${PGBACKREST_STANZA:-citus_worker1}"
BACKUP_SERVER="${PGBACKUP_SERVER:-pgbackup_server}"
BACKUP_USER="${PGBACKUP_USER:-bgbackrest}"

# 1. Generate SSH Host Keys (Requires root/sudo)
# sudo ssh-keygen -A

# 2. Generate User SSH Keys for 'postgres' if they don't exist
if [ ! -f ~/.ssh/id_ed25519 ]; then
    ssh-keygen -t ed25519 -N "" -f /var/lib/postgresql/.ssh/id_ed25519
    chmod 600 /var/lib/postgresql/.ssh/id_ed25519
    chmod 644 /var/lib/postgresql/.ssh/id_ed25519.pub
else
    echo -e "${GREEN}SSH key already exists${NC}"
fi

# 3. Ensure the Backup Server is in known_hosts to avoid "Host key verification failed"
if [ ! -f "/var/lib/postgresql/.ssh/known_hosts" ]; then
    touch /var/lib/postgresql/.ssh/known_hosts
    chown postgres:postgres /var/lib/postgresql/.ssh/known_hosts
    chmod 600 /var/lib/postgresql/.ssh/known_hosts
fi

# Add backup server to known_hosts if not already present
if ! ssh-keygen -F "$BACKUP_SERVER" >/dev/null 2>&1; then
    echo -e "${YELLOW}Adding backup server to known_hosts...${NC}"
    ssh-keyscan -H "$BACKUP_SERVER" >> /var/lib/postgresql/.ssh/known_hosts 2>/dev/null || true
fi

sshpass -p '123open' ssh-copy-id pgbackrest@pgbackup_server 2>/dev/null || true

# 4. Start the SSH Daemon
sudo /usr/sbin/sshd -p 2222

# 5. Now start Patroni
exec patroni /etc/patroni/patroni.yml