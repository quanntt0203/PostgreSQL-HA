# PostgreSQL Citus HA Cluster Management Script

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("start", "stop", "restart", "status", "setup", "test", "logs")]
    [string]$Action,
    
    [string]$Service = "all"
)

$ComposeFile = "D:\postgresql-ha\patroni-MMA\citus\docker-compose-full.yml"

function Write-Status {
    param([string]$Message, [string]$Color = "White")
    Write-Host $Message -ForegroundColor $Color
}

function Start-Cluster {
    Write-Status "Starting PostgreSQL Citus HA Cluster..." "Green"
    docker-compose -f $ComposeFile up -d
    
    if ($LASTEXITCODE -eq 0) {
        Write-Status "Cluster started successfully!" "Green"
        Show-ConnectionInfo
    } else {
        Write-Status "Failed to start cluster" "Red"
    }
}

function Stop-Cluster {
    Write-Status "Stopping PostgreSQL Citus HA Cluster..." "Yellow"
    docker-compose -f $ComposeFile down
    
    if ($LASTEXITCODE -eq 0) {
        Write-Status "Cluster stopped successfully!" "Green"
    } else {
        Write-Status "Failed to stop cluster" "Red"
    }
}

function Restart-Cluster {
    Write-Status "Restarting PostgreSQL Citus HA Cluster..." "Yellow"
    docker-compose -f $ComposeFile restart
    
    if ($LASTEXITCODE -eq 0) {
        Write-Status "Cluster restarted successfully!" "Green"
        Show-ConnectionInfo
    } else {
        Write-Status "Failed to restart cluster" "Red"
    }
}

function Show-Status {
    Write-Status "PostgreSQL Citus HA Cluster Status:" "Cyan"
    docker-compose -f $ComposeFile ps
    
    Write-Host ""
    Write-Status "Patroni Cluster Status:" "Cyan"
    try {
        $patroniStatus = docker exec coord1 patronictl -c etcd://etcd:2379 list citus_cluster 2>$null
        if ($patroniStatus) {
            Write-Host $patroniStatus
        } else {
            Write-Status "Unable to retrieve Patroni status" "Yellow"
        }
    } catch {
        Write-Status "Patroni status unavailable" "Yellow"
    }
    
    Write-Host ""
    Write-Status "Citus Worker Nodes:" "Cyan"
    try {
        $citusNodes = docker exec coord1 psql -h localhost -p 5432 -U postgres -d citus_db -t -c "SELECT * FROM citus_get_active_worker_nodes();" 2>$null
        if ($citusNodes) {
            Write-Host $citusNodes
        } else {
            Write-Status "Unable to retrieve Citus worker status" "Yellow"
        }
    } catch {
        Write-Status "Citus status unavailable" "Yellow"
    }
}

function Setup-Cluster {
    Write-Status "Setting up Citus cluster configuration..." "Green"
    
    # Wait for services to be ready
    Write-Status "Waiting for services to be ready..." "Yellow"
    Start-Sleep -Seconds 30
    
    # Run the setup script
    try {
        . "D:\postgresql-ha\patroni-MMA\citus\setup_cluster.ps1"
    } catch {
        Write-Status "Setup script failed: $($_.Exception.Message)" "Red"
    }
}

function Test-Cluster {
    Write-Status "Testing Citus cluster..." "Cyan"
    
    # Test coordinator connectivity
    Write-Status "Testing coordinator connectivity..." "Yellow"
    $coordTest = docker exec coord1 pg_isready -h localhost -p 5432
    Write-Host "Coordinator 1: $coordTest"
    
    $coordTest2 = docker exec coord2 pg_isready -h localhost -p 5432
    Write-Host "Coordinator 2: $coordTest2"
    
    $coordTest3 = docker exec coord3 pg_isready -h localhost -p 5432
    Write-Host "Coordinator 3: $coordTest3"
    
    # Test worker connectivity
    Write-Status "Testing worker connectivity..." "Yellow"
    $workerTest1 = docker exec work1-1 pg_isready -h localhost -p 5432
    Write-Host "Worker 1-1: $workerTest1"
    
    $workerTest2 = docker exec work1-2 pg_isready -h localhost -p 5432
    Write-Host "Worker 1-2: $workerTest2"
    
    $workerTest3 = docker exec work2-1 pg_isready -h localhost -p 5432
    Write-Host "Worker 2-1: $workerTest3"
    
    $workerTest4 = docker exec work2-2 pg_isready -h localhost -p 5432
    Write-Host "Worker 2-2: $workerTest4"
    
    # Test HAProxy
    Write-Status "Testing HAProxy..." "Yellow"
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:5000/stats" -TimeoutSec 5
        Write-Host "HAProxy Stats: Available at http://localhost:5000/stats"
    } catch {
        Write-Host "HAProxy Stats: Not available"
    }
    
    # Test sample query
    Write-Status "Testing sample distributed query..." "Yellow"
    try {
        $queryResult = docker exec coord1 psql -h localhost -p 5432 -U postgres -d citus_db -t -c "SELECT COUNT(*) as total_users FROM users;" 2>$null
        Write-Host "Sample query result: $queryResult users in distributed table"
    } catch {
        Write-Status "Sample query failed" "Red"
    }
}

function Show-Logs {
    if ($Service -eq "all") {
        Write-Status "Showing logs for all services..." "Cyan"
        docker-compose -f $ComposeFile logs --tail=50
    } else {
        Write-Status "Showing logs for $Service..." "Cyan"
        docker-compose -f $ComposeFile logs --tail=50 $Service
    }
}

function Show-ConnectionInfo {
    Write-Status "`nConnection Information:" "Cyan"
    Write-Host "┌─────────────────────────────────────────────────────────────┐" -ForegroundColor White
    Write-Host "│ PostgreSQL Citus HA Cluster Connection Details             │" -ForegroundColor White
    Write-Host "├─────────────────────────────────────────────────────────────┤" -ForegroundColor White
    Write-Host "│ Load Balanced Coordinators: localhost:5433                 │" -ForegroundColor Green
    Write-Host "│ Master Coordinator:         localhost:5434                 │" -ForegroundColor Green
    Write-Host "│ PgBouncer (Connection Pool): localhost:6432                │" -ForegroundColor Green
    Write-Host "│ HAProxy Stats:              http://localhost:5000/stats    │" -ForegroundColor Blue
    Write-Host "├─────────────────────────────────────────────────────────────┤" -ForegroundColor White
    Write-Host "│ Direct Coordinator Access:                                 │" -ForegroundColor Yellow
    Write-Host "│   Coordinator 1: localhost:5432                           │" -ForegroundColor White
    Write-Host "│   Coordinator 2: localhost:5442                           │" -ForegroundColor White
    Write-Host "│   Coordinator 3: localhost:5452                           │" -ForegroundColor White
    Write-Host "│ Direct Worker Access:                                      │" -ForegroundColor Yellow
    Write-Host "│   Worker 1-1: localhost:5462                              │" -ForegroundColor White
    Write-Host "│   Worker 1-2: localhost:5472                              │" -ForegroundColor White
    Write-Host "│   Worker 2-1: localhost:5482                              │" -ForegroundColor White
    Write-Host "│   Worker 2-2: localhost:5492                              │" -ForegroundColor White
    Write-Host "└─────────────────────────────────────────────────────────────┘" -ForegroundColor White
    Write-Host ""
    Write-Host "Quick Test Commands:" -ForegroundColor Cyan
    Write-Host "  psql -h localhost -p 6432 -U postgres -d citus_db" -ForegroundColor White
    Write-Host "  docker exec -it coord1 psql -U postgres -d citus_db" -ForegroundColor White
}

# Main execution
switch ($Action) {
    "start"   { Start-Cluster }
    "stop"    { Stop-Cluster }
    "restart" { Restart-Cluster }
    "status"  { Show-Status }
    "setup"   { Setup-Cluster }
    "test"    { Test-Cluster }
    "logs"    { Show-Logs }
}