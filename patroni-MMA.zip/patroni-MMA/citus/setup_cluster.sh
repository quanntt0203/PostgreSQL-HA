#!/bin/bash

# Citus Cluster Setup Script
echo "Starting Citus HA Cluster Setup..."

# Wait for all coordinators to be ready
echo "Waiting for coordinators to be ready..."
for i in {1..60}; do
    if pg_isready -h localhost -p 5432 && pg_isready -h localhost -p 5442 && pg_isready -h localhost -p 5452; then
        echo "All coordinators are ready!"
        break
    fi
    echo "Waiting for coordinators... ($i/60)"
    sleep 5
done

# Wait for all workers to be ready
echo "Waiting for workers to be ready..."
for i in {1..60}; do
    if pg_isready -h localhost -p 5462 && pg_isready -h localhost -p 5472 && pg_isready -h localhost -p 5482 && pg_isready -h localhost -p 5492; then
        echo "All workers are ready!"
        break
    fi
    echo "Waiting for workers... ($i/60)"
    sleep 5
done

# Connect to the master coordinator and set up the Citus cluster
echo "Setting up Citus cluster topology..."

# Add worker nodes to the cluster
psql -h localhost -p 5432 -U postgres -d citus_db -c "
-- Add worker group 1
SELECT citus_add_node('work1-1', 5432, groupid => 1, noderole => 'primary');
SELECT citus_add_node('work1-2', 5432, groupid => 1, noderole => 'secondary');

-- Add worker group 2  
SELECT citus_add_node('work2-1', 5432, groupid => 2, noderole => 'primary');
SELECT citus_add_node('work2-2', 5432, groupid => 2, noderole => 'secondary');

-- Set replication factor
SELECT citus_set_default_replication_factor(2);

-- Enable auto-failover for worker groups
SELECT citus_set_node_property('work1-1', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work1-2', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work2-1', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work2-2', 5432, 'shouldhaveshards', true);
"

echo "Creating sample distributed tables..."

psql -h localhost -p 5432 -U postgres -d citus_db -c "
-- Create sample tables
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE orders (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    order_date TIMESTAMP DEFAULT NOW()
);

-- Distribute the tables
SELECT create_distributed_table('users', 'id');
SELECT create_distributed_table('orders', 'user_id');

-- Insert sample data
INSERT INTO users (username, email) VALUES 
    ('john_doe', 'john@example.com'),
    ('jane_smith', 'jane@example.com'),
    ('bob_wilson', 'bob@example.com'),
    ('alice_brown', 'alice@example.com');

INSERT INTO orders (user_id, product_name, quantity, price) VALUES 
    (1, 'Laptop', 1, 999.99),
    (2, 'Mouse', 2, 25.50),
    (1, 'Keyboard', 1, 75.00),
    (3, 'Monitor', 1, 299.99),
    (4, 'Headphones', 1, 149.99);
"

echo "Citus cluster setup completed!"
echo "Connection details:"
echo "- Coordinators (via HAProxy): localhost:5433"
echo "- Master Coordinator: localhost:5434" 
echo "- PgBouncer: localhost:6432"
echo "- HAProxy Stats: http://localhost:5000/stats"
echo ""
echo "Test the cluster:"
echo "psql -h localhost -p 6432 -U postgres -d citus_db"