# PgBouncer Multi-Port HAProxy Configuration Guide

## Port Configuration Summary

### HAProxy Frontend Ports:
- **5400**: Coordinator Read-Write (Primary only)
- **5401**: Coordinator Read-Only (Any available coordinator)  
- **5402**: Coordinator Admin/Maintenance (Round-robin all coordinators)
- **5403**: Coordinator Direct Access (First available)
- **5500**: Workers (Load balanced across all leader workers)
- **5501**: Workers (Load balanced across all replica workers)

### PgBouncer Port:
- **6432**: Main PgBouncer port (handles all database connections)

## Connection Examples

### 1. Application Connections via PgBouncer

```bash
# Read-Write operations (goes to coordinator primary)
psql "host=localhost port=6432 dbname=citus_rw user=citus"

# Read-Only operations (distributed across coordinators)  
psql "host=localhost port=6432 dbname=citus_ro user=citus"

# Worker operations (distributed across worker nodes)
psql "host=localhost port=6432 dbname=citus_workers user=citus"

# Admin operations (maintenance, configuration)
psql "host=localhost port=6432 dbname=citus_admin user=postgres"
```

### 2. Direct HAProxy Connections (bypassing PgBouncer)

```bash
# Direct coordinator read-write
psql "host=localhost port=5400 dbname=citus_db user=citus"

# Direct coordinator read-only
psql "host=localhost port=5401 dbname=citus_db user=citus" 

# Direct worker access
psql "host=localhost port=5500 dbname=citus_db user=citus"
```

### 3. Direct Node Connections (bypassing both HAProxy and PgBouncer)

```bash
# Direct coordinator nodes via PgBouncer
psql "host=localhost port=6432 dbname=coord1_direct user=citus"
psql "host=localhost port=6432 dbname=coord2_direct user=citus"

# Direct worker nodes via PgBouncer  
psql "host=localhost port=6432 dbname=worker1_direct user=citus"
```

## Configuration Benefits

### 1. **Load Distribution**
- Read traffic distributed across multiple coordinators (port 5401)
- Write traffic directed to primary coordinator (port 5400)
- Worker queries load balanced (port 5500)

### 2. **Connection Pooling Optimization**
- Different pool sizes for different workload types
- Separate pools for read/write/admin operations
- Efficient connection reuse across multiple HAProxy backends

### 3. **High Availability**
- Automatic failover through HAProxy health checks
- Backup coordinators ready for promotion
- Isolated connection pools prevent resource contention

### 4. **Operational Flexibility**
- Direct node access for maintenance
- Admin operations isolated from application traffic
- Multiple connection strategies available

## Pool Configuration Strategy

| Database Target | Pool Size | Max Connections | Use Case |
|----------------|-----------|----------------|----------|
| citus_rw | 20 | 25 | Primary application writes |
| citus_ro | 15 | 20 | Application reads |
| citus_admin | 5 | 10 | Administrative operations |
| citus_workers | 20 | 25 | Distributed queries |
| *_direct | 5 | 10 | Maintenance/debugging |

## Monitoring Commands

```bash
# Check PgBouncer status
psql "host=localhost port=6432 dbname=pgbouncer user=postgres" -c "SHOW POOLS;"

# Check HAProxy stats
curl http://localhost:5000/stats

# Monitor specific database connections
psql "host=localhost port=6432 dbname=pgbouncer user=postgres" -c "SHOW DATABASES;"
```