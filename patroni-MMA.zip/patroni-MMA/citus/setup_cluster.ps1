# Citus Cluster Setup Script (PowerShell)
Write-Host "Starting Citus HA Cluster Setup..." -ForegroundColor Green

# Wait for all coordinators to be ready
Write-Host "Waiting for coordinators to be ready..." -ForegroundColor Yellow
for ($i = 1; $i -le 60; $i++) {
    $coord1 = docker exec coord1 pg_isready -h localhost -p 5432 2>$null
    $coord2 = docker exec coord2 pg_isready -h localhost -p 5432 2>$null  
    $coord3 = docker exec coord3 pg_isready -h localhost -p 5432 2>$null
    
    if ($coord1 -match "accepting connections" -and $coord2 -match "accepting connections" -and $coord3 -match "accepting connections") {
        Write-Host "All coordinators are ready!" -ForegroundColor Green
        break
    }
    Write-Host "Waiting for coordinators... ($i/60)" -ForegroundColor Yellow
    Start-Sleep -Seconds 5
}

# Wait for all workers to be ready
Write-Host "Waiting for workers to be ready..." -ForegroundColor Yellow
for ($i = 1; $i -le 60; $i++) {
    $work11 = docker exec work1-1 pg_isready -h localhost -p 5432 2>$null
    $work12 = docker exec work1-2 pg_isready -h localhost -p 5432 2>$null
    $work21 = docker exec work2-1 pg_isready -h localhost -p 5432 2>$null
    $work22 = docker exec work2-2 pg_isready -h localhost -p 5432 2>$null
    
    if ($work11 -match "accepting connections" -and $work12 -match "accepting connections" -and 
        $work21 -match "accepting connections" -and $work22 -match "accepting connections") {
        Write-Host "All workers are ready!" -ForegroundColor Green
        break
    }
    Write-Host "Waiting for workers... ($i/60)" -ForegroundColor Yellow
    Start-Sleep -Seconds 5
}

# Set up the Citus cluster topology
Write-Host "Setting up Citus cluster topology..." -ForegroundColor Yellow

$setupSql = @"
-- Add worker group 1
SELECT citus_add_node('work1-1', 5432, groupid => 1, noderole => 'primary');
SELECT citus_add_node('work1-2', 5432, groupid => 1, noderole => 'secondary');

-- Add worker group 2  
SELECT citus_add_node('work2-1', 5432, groupid => 2, noderole => 'primary');
SELECT citus_add_node('work2-2', 5432, groupid => 2, noderole => 'secondary');

-- Set replication factor
SELECT citus_set_default_replication_factor(2);

-- Enable auto-failover for worker groups
SELECT citus_set_node_property('work1-1', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work1-2', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work2-1', 5432, 'shouldhaveshards', true);
SELECT citus_set_node_property('work2-2', 5432, 'shouldhaveshards', true);
"@

docker exec coord1 psql -h localhost -p 5432 -U postgres -d citus_db -c $setupSql

Write-Host "Creating sample distributed tables..." -ForegroundColor Yellow

$sampleSql = @"
-- Create sample tables
CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS orders (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL,
    product_name VARCHAR(100) NOT NULL,
    quantity INTEGER NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    order_date TIMESTAMP DEFAULT NOW()
);

-- Distribute the tables
SELECT create_distributed_table('users', 'id');
SELECT create_distributed_table('orders', 'user_id');

-- Insert sample data
INSERT INTO users (username, email) VALUES 
    ('john_doe', 'john@example.com'),
    ('jane_smith', 'jane@example.com'),
    ('bob_wilson', 'bob@example.com'),
    ('alice_brown', 'alice@example.com')
ON CONFLICT (username) DO NOTHING;

INSERT INTO orders (user_id, product_name, quantity, price) VALUES 
    (1, 'Laptop', 1, 999.99),
    (2, 'Mouse', 2, 25.50),
    (1, 'Keyboard', 1, 75.00),
    (3, 'Monitor', 1, 299.99),
    (4, 'Headphones', 1, 149.99)
ON CONFLICT DO NOTHING;
"@

docker exec coord1 psql -h localhost -p 5432 -U postgres -d citus_db -c $sampleSql

Write-Host "Citus cluster setup completed!" -ForegroundColor Green
Write-Host ""
Write-Host "Connection details:" -ForegroundColor Cyan
Write-Host "- Coordinators (via HAProxy): localhost:5433" -ForegroundColor White
Write-Host "- Master Coordinator: localhost:5434" -ForegroundColor White
Write-Host "- PgBouncer: localhost:6432" -ForegroundColor White 
Write-Host "- HAProxy Stats: http://localhost:5000/stats" -ForegroundColor White
Write-Host ""
Write-Host "Test the cluster:" -ForegroundColor Cyan
Write-Host "docker exec -it citus_pgbouncer psql -h localhost -p 6432 -U postgres -d citus_db" -ForegroundColor White