#!/bin/bash
# Wrapper script to start services and setup pgBackRest

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Starting post-Patroni setup...${NC}"

# Start SSH service
echo -e "${YELLOW}Starting SSH service...${NC}"
/usr/sbin/sshd -p 2222

# Wait a moment for SSH to start
sleep 2

# Run pgBackRest setup
echo -e "${YELLOW}Running pgBackRest setup...${NC}"
if [ -f "/var/lib/postgresql/pgbackrest_setup.sh" ]; then
    /var/lib/postgresql/pgbackrest_setup.sh
else
    echo -e "${YELLOW}Warning: pgbackrest_setup.sh not found${NC}"
fi

echo -e "${GREEN}Post-Patroni setup completed${NC}"