#!/bin/bash
# Bootstrap script for Citus coordinator node

set -e

echo "Starting Citus bootstrap process..."

# Wait for PostgreSQL to be ready
until pg_isready -h localhost -p 5432 -U postgres; do
  echo "Waiting for PostgreSQL to be ready..."
  sleep 2
done

# Connect and setup Citus
psql -U postgres -d citus -c "
-- Create Citus extension
CREATE EXTENSION IF NOT EXISTS citus;

-- Configure this node as coordinator
SELECT citus_set_coordinator_host('coord1', 5432);

-- Create replication user if not exists
DO \$\$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'replicator') THEN
        CREATE USER replicator WITH REPLICATION PASSWORD 'replpass';
    END IF;
END
\$\$;

-- Grant necessary permissions
GRANT CONNECT ON DATABASE citus TO replicator;
GRANT USAGE ON SCHEMA public TO replicator;

-- Create some basic monitoring views
CREATE OR REPLACE VIEW citus_cluster_status AS
SELECT 
    node_name,
    node_host,
    node_port,
    node_cluster,
    hasmetadata,
    isactive,
    node_role,
    shouldhaveshards
FROM citus_get_active_worker_nodes()
UNION ALL
SELECT 
    'coordinator' as node_name,
    'coord1' as node_host,
    5432 as node_port,
    'default' as node_cluster,
    true as hasmetadata,
    true as isactive,
    'primary' as node_role,
    false as shouldhaveshards;
"

echo "Citus coordinator bootstrap completed successfully!"