# PostgreSQL Citus HA Cluster Monitoring Script

param(
    [int]$Interval = 30,
    [switch]$Continuous
)

function Write-TimestampedMessage {
    param([string]$Message, [string]$Color = "White")
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

function Get-ClusterHealth {
    $health = @{
        Timestamp = Get-Date
        Coordinators = @{}
        Workers = @{}
        Services = @{}
        Overall = "Unknown"
    }
    
    # Check coordinators
    $coordinators = @("coord1", "coord2", "coord3")
    foreach ($coord in $coordinators) {
        try {
            $status = docker exec $coord pg_isready -h localhost -p 5432 2>$null
            $health.Coordinators[$coord] = if ($status -match "accepting connections") { "Healthy" } else { "Unhealthy" }
        } catch {
            $health.Coordinators[$coord] = "Unreachable"
        }
    }
    
    # Check workers  
    $workers = @("work1-1", "work1-2", "work2-1", "work2-2")
    foreach ($worker in $workers) {
        try {
            $status = docker exec $worker pg_isready -h localhost -p 5432 2>$null
            $health.Workers[$worker] = if ($status -match "accepting connections") { "Healthy" } else { "Unhealthy" }
        } catch {
            $health.Workers[$worker] = "Unreachable"
        }
    }
    
    # Check services
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:5000/stats" -TimeoutSec 5 2>$null
        $health.Services["HAProxy"] = "Healthy"
    } catch {
        $health.Services["HAProxy"] = "Unreachable"
    }
    
    try {
        $etcdStatus = docker exec citus_etcd etcdctl --endpoints=http://localhost:2379 endpoint health 2>$null
        $health.Services["etcd"] = if ($etcdStatus -match "healthy") { "Healthy" } else { "Unhealthy" }
    } catch {
        $health.Services["etcd"] = "Unreachable"
    }
    
    try {
        $pgBouncerStatus = docker exec citus_pgbouncer pg_isready -h localhost -p 6432 2>$null
        $health.Services["PgBouncer"] = if ($pgBouncerStatus -match "accepting connections") { "Healthy" } else { "Unhealthy" }
    } catch {
        $health.Services["PgBouncer"] = "Unreachable"
    }
    
    # Calculate overall health
    $healthyCoords = ($health.Coordinators.Values | Where-Object { $_ -eq "Healthy" }).Count
    $healthyWorkers = ($health.Workers.Values | Where-Object { $_ -eq "Healthy" }).Count
    $healthyServices = ($health.Services.Values | Where-Object { $_ -eq "Healthy" }).Count
    
    if ($healthyCoords -ge 2 -and $healthyWorkers -ge 2 -and $healthyServices -ge 2) {
        $health.Overall = "Healthy"
    } elseif ($healthyCoords -ge 1 -and $healthyWorkers -ge 1) {
        $health.Overall = "Degraded"
    } else {
        $health.Overall = "Critical"
    }
    
    return $health
}

function Show-ClusterStatus {
    $health = Get-ClusterHealth
    
    Clear-Host
    Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Blue
    Write-Host "                    PostgreSQL Citus HA Cluster Monitor                        " -ForegroundColor Blue  
    Write-Host "═══════════════════════════════════════════════════════════════════════════════" -ForegroundColor Blue
    Write-Host ""
    
    # Overall Status
    $overallColor = switch ($health.Overall) {
        "Healthy" { "Green" }
        "Degraded" { "Yellow" }
        "Critical" { "Red" }
        default { "Gray" }
    }
    Write-Host "Overall Cluster Health: " -NoNewline
    Write-Host $health.Overall -ForegroundColor $overallColor
    Write-Host "Last Updated: " -NoNewline  
    Write-Host $health.Timestamp.ToString("yyyy-MM-dd HH:mm:ss") -ForegroundColor Cyan
    Write-Host ""
    
    # Coordinators
    Write-Host "┌─ Coordinators (Group 0) ──────────────────────────────────────────────────────┐" -ForegroundColor Blue
    foreach ($coord in $health.Coordinators.GetEnumerator()) {
        $statusColor = if ($coord.Value -eq "Healthy") { "Green" } elseif ($coord.Value -eq "Unhealthy") { "Yellow" } else { "Red" }
        Write-Host "│ " -NoNewline -ForegroundColor Blue
        Write-Host ("{0,-15}" -f $coord.Key) -NoNewline
        Write-Host (" : ") -NoNewline  
        Write-Host ("{0,-12}" -f $coord.Value) -ForegroundColor $statusColor -NoNewline
        Write-Host (" │") -ForegroundColor Blue
    }
    Write-Host "└───────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Blue
    Write-Host ""
    
    # Workers
    Write-Host "┌─ Workers ──────────────────────────────────────────────────────────────────────┐" -ForegroundColor Blue
    Write-Host "│ Group 1:                                                                       │" -ForegroundColor Blue
    foreach ($worker in @("work1-1", "work1-2")) {
        $status = $health.Workers[$worker]
        $statusColor = if ($status -eq "Healthy") { "Green" } elseif ($status -eq "Unhealthy") { "Yellow" } else { "Red" }
        Write-Host "│   " -NoNewline -ForegroundColor Blue
        Write-Host ("{0,-15}" -f $worker) -NoNewline
        Write-Host (" : ") -NoNewline  
        Write-Host ("{0,-12}" -f $status) -ForegroundColor $statusColor -NoNewline
        Write-Host ("   │") -ForegroundColor Blue
    }
    Write-Host "│ Group 2:                                                                       │" -ForegroundColor Blue
    foreach ($worker in @("work2-1", "work2-2")) {
        $status = $health.Workers[$worker]
        $statusColor = if ($status -eq "Healthy") { "Green" } elseif ($status -eq "Unhealthy") { "Yellow" } else { "Red" }
        Write-Host "│   " -NoNewline -ForegroundColor Blue
        Write-Host ("{0,-15}" -f $worker) -NoNewline
        Write-Host (" : ") -NoNewline  
        Write-Host ("{0,-12}" -f $status) -ForegroundColor $statusColor -NoNewline
        Write-Host ("   │") -ForegroundColor Blue
    }
    Write-Host "└───────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Blue
    Write-Host ""
    
    # Services
    Write-Host "┌─ Infrastructure Services ──────────────────────────────────────────────────────┐" -ForegroundColor Blue
    foreach ($service in $health.Services.GetEnumerator()) {
        $statusColor = if ($service.Value -eq "Healthy") { "Green" } elseif ($service.Value -eq "Unhealthy") { "Yellow" } else { "Red" }
        Write-Host "│ " -NoNewline -ForegroundColor Blue
        Write-Host ("{0,-15}" -f $service.Key) -NoNewline
        Write-Host (" : ") -NoNewline  
        Write-Host ("{0,-12}" -f $service.Value) -ForegroundColor $statusColor -NoNewline
        Write-Host (" │") -ForegroundColor Blue
    }
    Write-Host "└───────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Blue
    Write-Host ""
    
    # Connection Information
    Write-Host "┌─ Connection Endpoints ─────────────────────────────────────────────────────────┐" -ForegroundColor Cyan
    Write-Host "│ PgBouncer (Recommended): localhost:6432                                       │" -ForegroundColor Green
    Write-Host "│ HAProxy Load Balanced:   localhost:5433                                       │" -ForegroundColor Green  
    Write-Host "│ HAProxy Master:          localhost:5434                                       │" -ForegroundColor Green
    Write-Host "│ HAProxy Stats:           http://localhost:5000/stats                          │" -ForegroundColor Blue
    Write-Host "└───────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Cyan
    
    if ($Continuous) {
        Write-Host ""
        Write-Host "Press Ctrl+C to stop monitoring..." -ForegroundColor Gray
        Write-Host "Next update in $Interval seconds..." -ForegroundColor Gray
    }
}

function Get-PatroniStatus {
    try {
        $patroniOutput = docker exec coord1 patronictl -c etcd://etcd:2379 list citus_cluster 2>$null
        if ($patroniOutput) {
            Write-Host ""
            Write-Host "┌─ Patroni Cluster Status ───────────────────────────────────────────────────────┐" -ForegroundColor Magenta
            $patroniOutput -split "`n" | ForEach-Object {
                if ($_.Trim()) {
                    Write-Host "│ $($_)" -ForegroundColor White
                }
            }
            Write-Host "└─────────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Magenta
        }
    } catch {
        Write-TimestampedMessage "Unable to retrieve Patroni status" "Yellow"
    }
}

function Get-CitusWorkerStatus {
    try {
        $citusOutput = docker exec coord1 psql -h localhost -p 5432 -U postgres -d citus_db -t -c "SELECT nodeid, nodename, nodeport, noderack, hasmetadata, isactive, noderole, groupid FROM pg_dist_node ORDER BY groupid, nodeid;" 2>$null
        if ($citusOutput) {
            Write-Host ""
            Write-Host "┌─ Citus Worker Nodes Status ────────────────────────────────────────────────────┐" -ForegroundColor Green
            Write-Host "│ ID │ Name      │ Port │ Group │ Role      │ Active │ Has Metadata           │" -ForegroundColor White
            Write-Host "├────┼───────────┼──────┼───────┼───────────┼────────┼────────────────────────┤" -ForegroundColor White
            $citusOutput -split "`n" | ForEach-Object {
                if ($_.Trim()) {
                    Write-Host "│ $($_)" -ForegroundColor White
                }
            }
            Write-Host "└─────────────────────────────────────────────────────────────────────────────────┘" -ForegroundColor Green
        }
    } catch {
        Write-TimestampedMessage "Unable to retrieve Citus worker status" "Yellow"
    }
}

# Main monitoring loop
if ($Continuous) {
    Write-TimestampedMessage "Starting continuous cluster monitoring (interval: ${Interval}s)" "Green"
    Write-TimestampedMessage "Press Ctrl+C to stop..." "Gray"
    
    try {
        while ($true) {
            Show-ClusterStatus
            Get-PatroniStatus
            Get-CitusWorkerStatus
            Start-Sleep -Seconds $Interval
        }
    } catch {
        Write-TimestampedMessage "Monitoring stopped" "Yellow"
    }
} else {
    Show-ClusterStatus
    Get-PatroniStatus
    Get-CitusWorkerStatus
}